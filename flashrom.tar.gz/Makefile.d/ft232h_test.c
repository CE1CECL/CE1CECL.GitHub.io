#include <ftdi.h>

enum ftdi_chip_type type = TYPE_232H;