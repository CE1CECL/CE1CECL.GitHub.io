#include <linux/i2c-dev.h>
#include <linux/i2c.h>

int main(int argc, char **argv)
{
	(void)argc;
	(void)argv;
	return 0;
}
