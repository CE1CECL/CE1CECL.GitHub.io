#include <linux/types.h>
#include <linux/spi/spidev.h>

int main(int argc, char **argv)
{
	(void)argc;
	(void)argv;
	return 0;
}
